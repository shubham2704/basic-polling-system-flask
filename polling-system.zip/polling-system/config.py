BLOCK_DIRNAME = 'polls'
LOG_PATH = 'logs.log'
ARCHIVE_PATH = './old_polls.zip'