# polling-system

## How to run project


```
pip install virtualenv
mkvirtualenv "your virtual enviornment name"

activate the virtual enviornment by:
workon "your virtual enviornment name"

pip install flask
pip install Flask-API


python polling_api.py
```

## open on localhost 

Now head over to http://127.0.0.1:5500/templates

## License

Polling system is available under the MIT license.


